# PNG Adventure: Moresby Run — Lite v0.1

A playable, lightweight PNG-inspired side-scrolling endless runner prototype. All game artwork, sound and UI are generated locally; no third-party assets, external CDNs, online accounts or purchases are required.

## Play immediately

**Easiest:** Open `PNG_Adventure_Play_Now.html` from the download alongside this project (or download it separately). It contains all game code and styling in one file. No installation needed. The standalone file is for local play, not PWA installation.

**Full PWA / local web server:**

```bash
# From this project folder, with Python installed:
python -m http.server 8000
# Then open http://localhost:8000
```

The PWA can be installed in supported browsers when served from `localhost` or over HTTPS. After one successful load of the project assets, the service worker caches the game for offline play. `file://` URLs cannot use the PWA service worker (but the standalone game still plays locally).

**Deploy to Cloudflare Pages:** Connect a repository containing these files and choose a static build with no framework and no build command; publish the repository root. Alternatively upload the static files through your hosting service. HTTPS hosting enables PWA installation and service workers. Render's Static Site hosting or GitHub Pages can also serve this project.

## Controls

- **Desktop:** `Space` or `↑` to jump; `↓` to slide; `P` or `Esc` to pause/resume.
- **Mobile:** Landscape recommended; use the onscreen **JUMP** and **SLIDE** buttons.
- **Gameplay:** Avoid crates (jump), potholes (jump), and low signs (slide). You have 3 hearts per run; collect coins to unlock 2 additional cosmetic outfits.
- Score, best score, collected banked coins, selected outfit and muted sound state are stored on-device using `localStorage`. Progress is not synced across devices.

## Project structure

- `index.html` — web app shell and UI
- `style.css` — responsive styling
- `app.js` — the game loop, procedural canvas graphics, physics, obstacle generation, sound, UI, and local persistence
- `manifest.webmanifest` — PWA installation metadata
- `sw.js` — asset precache/offline support for secure origins
- `icon-192.png`, `icon-512.png` — app icons
- `tests/smoke.test.js` — dependency-free Node.js logic smoke test

## Testing

```bash
node --check app.js
node tests/smoke.test.js
```

The smoke test exercises the menus, controls, scoring, pause, resume, finish, save, and locker logic using a fake Canvas/DOM. Visual rendering and actual Android installation still need real-device testing.

## Technical decisions

For this **first playable proof of concept**, the game uses native HTML5 Canvas + JavaScript, not Phaser. That avoids a download-heavy dependency and means it runs from a single HTML file. If the prototype is fun enough to grow into a larger game with tilemaps, hand-designed platform levels and sprite animations, we can migrate the core mechanics to **Phaser 4 + TypeScript + Vite** while keeping the existing visual direction and PWA goals. The current browser game uses no backend.

## Next sprint ideas

1. Real mobile device testing and physics balancing across low-end Android phones.
2. Replace programmatic drawings with a distinctive, consistent PNG-inspired character and environmental sprite set.
3. Add short hand-designed stages alongside endless mode, with an optional freely controlled character.
4. Publish the PWA on an HTTPS URL, then instrument privacy-respecting play/retention analytics.
5. Only after genuine engagement, evaluate optional advertising, sponsorships and guaranteed cosmetics.

## Notes

This is a prototype. It is not connected to any existing GitHub repo, Cloudflare account, Render deployment or payment provider, and does not use real politicians' names or likenesses. The soundtrack is off by default only if the player mutes it; sound begins after a user interaction. Game information never leaves the device.
