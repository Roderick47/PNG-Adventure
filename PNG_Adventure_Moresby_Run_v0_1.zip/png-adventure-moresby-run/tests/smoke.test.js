// Dependency-free game logic smoke test; run: node tests/smoke.test.js
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const path = require('path');
const callbacks = new Map(), elements = new Map();
let frameCallback = null;
class ClassList {
  constructor() { this.s = new Set(); }
  add(x) { this.s.add(x); }
  remove(x) { this.s.delete(x); }
  toggle(x, enabled) { if (enabled) this.add(x); else this.remove(x); }
  contains(x) { return this.s.has(x); }
}
function element(id) {
  if (!elements.has(id)) elements.set(id, {
    id, innerHTML: '', textContent: '', classList: new ClassList(),
    dataset: {}, addEventListener(type,cb){callbacks.set(id+':'+type,cb)},
    setAttribute(){}, closest(){return this}
  });
  return elements.get(id);
}
const ctx = new Proxy({}, {get(target,key){
  if (key==='createLinearGradient') return () => ({addColorStop(){}});
  if (key==='measureText') return () => ({width:20});
  return target[key] || (()=>{});
},set(target,key,value){target[key]=value;return true}});
element('game-canvas').getContext = () => ctx;
const doc = {getElementById:element,addEventListener(type,cb){callbacks.set('document:'+type,cb)}};
const local = new Map();
const context = {
  document:doc, localStorage:{getItem:k=>local.get(k)||null,setItem:(k,v)=>local.set(k,v)},
  navigator:{}, window:{addEventListener(type,cb){callbacks.set('window:'+type,cb)}},
  requestAnimationFrame(cb){frameCallback=cb}, console, Math, JSON, Set,
  setTimeout(cb){cb()},
};
const source = fs.readFileSync(path.join(__dirname,'..','app.js'),'utf8');
vm.runInNewContext(source,context,{filename:'app.js'});
function click(action) {
  const target={dataset:{action},closest(){return this}};
  return callbacks.get('document:click')({target});
}
function key(code) {callbacks.get('document:keydown')({code,repeat:false,preventDefault(){}})}
function frames(n,dt=16.7) {let t=0; for(let i=0;i<n;i++){t+=(dt); frameCallback(t)} }
(async()=>{
  assert(element('overlay').innerHTML.includes('START RUN'));
  await click('how'); assert(element('overlay').innerHTML.includes('HOW TO PLAY'));
  await click('menu'); await click('play');
  assert(element('overlay').classList.contains('is-hidden'));
  frames(180); key('Space'); frames(50);
  assert(parseInt(element('hud-score').textContent.replace(/,/g,''))>0);
  key('KeyP'); assert(element('overlay').innerHTML.includes('PAUSED'));
  await click('resume'); assert(element('overlay').classList.contains('is-hidden'));
  key('KeyP'); await click('quit');
  assert(element('overlay').innerHTML.includes('PLAY AGAIN'));
  assert(local.has('png-adventure-moresby-run-v1'));
  await click('locker'); assert(element('overlay').innerHTML.includes('OUTFIT LOCKER'));
  await click('menu'); assert(element('overlay').innerHTML.includes('START RUN'));
  console.log('PASS: menu, how-to, start, scoring, keyboard jump, pause, resume, finish, save, locker, home');
})().catch(err => { console.error(err); process.exit(1) });
