/* PNG Adventure: Moresby Run — dependency-free playable prototype (v0.1).
   All artwork is drawn with Canvas2D; no external assets or network required. */
(() => {
  'use strict';
  const W = 960, H = 540, FLOOR = 425, KEY = 'png-adventure-moresby-run-v1';
  const canvas = document.getElementById('game-canvas');
  const ctx = canvas.getContext('2d', { alpha: false });
  const overlay = document.getElementById('overlay');
  const hud = document.getElementById('game-hud');
  const touchControls = document.getElementById('touch-controls');
  const toast = document.getElementById('toast');
  const soundButton = document.getElementById('sound-button');
  const scoreText = document.getElementById('hud-score');
  const coinsText = document.getElementById('hud-coins');
  const distanceText = document.getElementById('hud-distance');
  const heartsText = document.getElementById('hearts');
  const outfits = {
    red: { name: 'Classic Red', color: '#ea5544', price: 0, emoji: '🔴' },
    blue: { name: 'Coastal Blue', color: '#1c9fbf', price: 75, emoji: '🔵' },
    gold: { name: 'Golden Runner', color: '#f4b943', price: 200, emoji: '🟡' }
  };
  const save = { bank: 0, best: 0, unlocked: ['red'], outfit: 'red', muted: false };
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || '{}');
    save.bank = Number.isFinite(raw.bank) ? Math.max(0, Math.floor(raw.bank)) : 0;
    save.best = Number.isFinite(raw.best) ? Math.max(0, Math.floor(raw.best)) : 0;
    save.unlocked = Array.isArray(raw.unlocked) ? raw.unlocked.filter(id => id in outfits) : ['red'];
    if (!save.unlocked.includes('red')) save.unlocked.unshift('red');
    save.outfit = save.unlocked.includes(raw.outfit) ? raw.outfit : 'red';
    save.muted = Boolean(raw.muted);
  } catch (e) { /* Storage can be disabled; gameplay still works. */ }
  let audio;
  const persist = () => { try { localStorage.setItem(KEY, JSON.stringify(save)); } catch (e) {} };
  const rnd = (a, b) => a + Math.random() * (b - a);
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const fmt = n => Math.floor(n).toLocaleString('en-US');
  let state = 'menu', t = 0, sceneOffset = 0, last = 0, toastTimer = 0;
  let distance = 0, elapsed = 0, speed = 320, spawnTimer = 3.2, runCoins = 0, score = 0;
  let hearts = 3, invulnerable = 0, objects = [], particles = [];
  const player = { x: 205, z: 0, vz: 0, slide: 0, step: 0 };

  function beep(type) {
    if (save.muted) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      if (!audio) audio = new AudioCtx();
      if (audio.state === 'suspended') audio.resume();
      const osc = audio.createOscillator(), gain = audio.createGain();
      const now = audio.currentTime;
      const specs = { jump: [380, 640, .12, 'sine'], coin: [750, 1070, .09, 'triangle'], hit: [210, 85, .22, 'sawtooth'], over: [450, 150, .4, 'triangle'], shop: [580, 880, .19, 'sine'] };
      const [a, b, dur, wave] = specs[type] || specs.jump;
      osc.type = wave; osc.frequency.setValueAtTime(a, now); osc.frequency.exponentialRampToValueAtTime(b, now + dur);
      gain.gain.setValueAtTime(.045, now); gain.gain.exponentialRampToValueAtTime(.0001, now + dur);
      osc.connect(gain).connect(audio.destination); osc.start(now); osc.stop(now + dur + .01);
    } catch (e) {}
  }
  function notify(message) {
    toast.textContent = message; toast.classList.add('active'); toastTimer = 1.25;
  }
  function setSoundButton() { soundButton.textContent = save.muted ? '♪ OFF' : '♪ ON'; }
  setSoundButton();
  soundButton.addEventListener('click', () => { save.muted = !save.muted; persist(); setSoundButton(); if (!save.muted) beep('shop'); });

  function setHUD(show) {
    hud.classList.toggle('is-hidden', !show);
    touchControls.classList.toggle('is-hidden', !show);
  }
  function updateHUD() {
    scoreText.textContent = fmt(score);
    coinsText.innerHTML = '<span class="coin-icon">●</span> ' + fmt(runCoins);
    distanceText.textContent = fmt(distance / 12) + ' m';
    heartsText.textContent = '♥ '.repeat(hearts) + '♡ '.repeat(3 - hearts);
    heartsText.setAttribute('aria-label', hearts + ' of 3 hearts');
  }
  function showOverlay(html) { overlay.innerHTML = html; overlay.classList.remove('is-hidden'); }
  function hideOverlay() { overlay.classList.add('is-hidden'); overlay.innerHTML = ''; }

  function showMenu() {
    state = 'menu'; setHUD(false);
    showOverlay(`
      <div class="menu">
        <div class="menu-content">
          <div class="eyebrow">One city. Endless adventure.</div>
          <h1>PNG<br><span class="accent">ADVENTURE</span></h1>
          <p>Dash through Moresby, leap over hazards, grab golden coins and chase your next high score. How far can you go?</p>
          <div class="menu-actions">
            <button class="game-btn primary" data-action="play">▶ &nbsp; START RUN</button>
            <button class="game-btn secondary" data-action="locker">◈ &nbsp; OUTFITS</button>
            <button class="game-btn ghost" data-action="how">? &nbsp; HOW TO PLAY</button>
          </div>
          <div class="menu-stats">
            <div><small>PERSONAL BEST</small><strong>${fmt(save.best)} PTS</strong></div>
            <div><small>YOUR COINS</small><strong>● ${fmt(save.bank)}</strong></div>
          </div>
        </div>
        <div class="tip-card" aria-hidden="true">
          <div class="tip-title">MISSION BRIEF</div>
          <p>Survive the streets. Beat your own record.</p>
          <div class="tip-row"><span class="key">↑</span> Jump the crates &amp; holes</div>
          <div class="tip-row"><span class="key">↓</span> Slide under banners</div>
          <div class="tip-row"><span class="key">●</span> Collect golden coins</div>
          <div class="small-rule"></div>
          <div class="tip-footer">Three hearts per run. Collect coins to unlock fresh outfits. Save progress on this device.</div>
        </div>
      </div>`);
  }
  function showHow() {
    state = 'how'; setHUD(false);
    showOverlay(`<div class="modal-mini"><div class="eyebrow">The basics</div><h2>HOW TO PLAY</h2>
      <p>Your character runs automatically. Jump over <b>crates and potholes</b>, and slide underneath <b>low banners</b>.</p>
      <ul><li><b>Keyboard:</b> Space / ↑ to jump, ↓ to slide, P / Esc to pause.</li>
      <li><b>Phone:</b> Use the JUMP and SLIDE buttons at the bottom corners.</li>
      <li>You have <b>three hearts</b>. Each hit costs one heart, then grants brief protection.</li>
      <li>Collect coins to buy outfits. Scores and coins are saved <b>locally</b> — no login needed.</li></ul>
      <button class="game-btn primary" data-action="play">▶ START RUN</button><button class="game-btn secondary" data-action="menu">BACK</button></div>`);
  }
  function showLocker() {
    state = 'locker'; setHUD(false);
    const cards = Object.entries(outfits).map(([id, o]) => {
      const owned = save.unlocked.includes(id), selected = save.outfit === id;
      const buttonText = selected ? '✓ EQUIPPED' : owned ? 'EQUIP' : `● ${o.price}`;
      return `<div class="locker-card"><span class="outfit">${o.emoji}</span><strong>${o.name}</strong><small>${owned ? 'UNLOCKED' : 'COSTS ' + o.price + ' COINS'}</small>
        <button class="game-btn ${selected ? 'secondary' : 'primary'}" data-action="outfit:${id}" ${selected ? 'disabled' : ''}>${buttonText}</button></div>`;
    }).join('');
    showOverlay(`<div class="modal-mini"><div class="eyebrow">Customize your runner</div><h2>OUTFIT LOCKER</h2>
      <p>Available coins: <b style="color:#ffd56a">● ${fmt(save.bank)}</b>. Earn more by completing runs. Outfits are cosmetic only.</p>
      <div class="locker-items">${cards}</div><button class="game-btn primary" data-action="play">▶ START RUN</button>
      <button class="game-btn secondary" data-action="menu">BACK TO MENU</button></div>`);
  }
  function startRun() {
    distance = 0; elapsed = 0; speed = 320; spawnTimer = 2.35; runCoins = 0; score = 0; hearts = 3;
    invulnerable = 0; objects = []; particles = []; player.z = 0; player.vz = 0; player.slide = 0;
    player.step = 0; state = 'running'; hideOverlay(); setHUD(true); updateHUD();
  }
  function pause() {
    if (state !== 'running') return;
    state = 'paused'; setHUD(true); touchControls.classList.add('is-hidden');
    showOverlay(`<div class="modal-mini"><div class="eyebrow">Take a break</div><h2>PAUSED</h2>
      <p>Your adventure is waiting. Your current score is <b>${fmt(score)}</b>.</p>
      <button class="game-btn primary" data-action="resume">▶ RESUME</button><button class="game-btn secondary" data-action="quit">END RUN</button></div>`);
  }
  function resume() { if (state !== 'paused') return; state = 'running'; hideOverlay(); setHUD(true); }
  function finishRun() {
    if (state !== 'running' && state !== 'paused') return;
    const previous = save.best;
    save.bank += runCoins;
    save.best = Math.max(save.best, score);
    persist(); beep('over'); state = 'over'; setHUD(false);
    const record = score > previous && score > 0;
    showOverlay(`<div class="modal-mini"><div class="eyebrow">Adventure complete</div>
      <div class="result-stars">${record ? '★ ★ ★' : '★ ★ ☆'}</div><h2>${record ? 'NEW PERSONAL BEST!' : 'NICE RUN!'}</h2>
      <p>${record ? 'You set a new record. ' : ''}Every run counts. Your collected coins have been added to your locker.</p>
      <div class="result-grid"><div class="result-cell"><small>SCORE</small><strong>${fmt(score)}</strong></div>
      <div class="result-cell"><small>DISTANCE</small><strong>${fmt(distance / 12)}m</strong></div>
      <div class="result-cell"><small>COINS</small><strong>+${fmt(runCoins)}</strong></div></div>
      <button class="game-btn primary" data-action="play">↻ PLAY AGAIN</button>
      <button class="game-btn secondary" data-action="share">↗ SHARE SCORE</button>
      <button class="game-btn secondary" data-action="locker">◈ OUTFITS</button>
      <button class="game-btn ghost" data-action="menu">MENU</button></div>`);
  }
  function jump() {
    if (state !== 'running' || player.z > 0 || player.slide > 0) return;
    player.vz = 780; beep('jump');
    addParticles(player.x - 7, FLOOR, '#ffe8bb', 4, 85);
  }
  function slide() {
    if (state !== 'running' || player.z > 0) return;
    player.slide = .72; addParticles(player.x - 15, FLOOR - 4, '#ffe5c1', 2, 70);
  }
  function spawnObstacle() {
    const allowed = elapsed < 8 ? ['crate', 'pothole'] : ['crate', 'pothole', 'banner'];
    const type = allowed[Math.floor(Math.random() * allowed.length)];
    const x = W + 40;
    const widths = { crate: 50, pothole: 87, banner: 94 };
    objects.push({ type, x, width: widths[type], hit: false });
    const coinY = type === 'banner' ? FLOOR - 26 : FLOOR - 126;
    for (let i = 0; i < 3; i++) objects.push({ type: 'coin', x: x + 125 + i * 39, y: coinY + (i === 1 ? -12 : 0), width: 22, hit: false });
    if (Math.random() < .27) objects.push({ type: 'coin', x: x - 80, y: FLOOR - 76, width: 22, hit: false });
  }
  function collide(a, b) { return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y; }
  function damage() {
    if (invulnerable > 0) return;
    hearts--; invulnerable = 1.55; beep('hit');
    addParticles(player.x, FLOOR - 35 - player.z, '#ff7777', 10, 160);
    if (hearts > 0) notify(hearts + (hearts === 1 ? ' HEART LEFT!' : ' HEARTS LEFT!'));
    if (hearts <= 0) finishRun();
  }
  function addParticles(x, y, color, count, power) {
    for (let i = 0; i < count; i++) particles.push({ x, y, vx: rnd(-power, power), vy: rnd(-power * 1.5, -20), life: rnd(.35, .75), maxLife: .75, color, size: rnd(3, 7) });
  }
  function update(dt) {
    t += dt;
    if (toastTimer > 0) { toastTimer -= dt; if (toastTimer <= 0) toast.classList.remove('active'); }
    sceneOffset += (state === 'running' ? speed : 45) * dt;
    if (state !== 'running') return;
    elapsed += dt; speed = Math.min(565, 320 + elapsed * 2.0); distance += speed * dt;
    player.step += dt * (speed / 30);
    if (player.z > 0 || player.vz > 0) {
      player.z += player.vz * dt;
      player.vz -= 1890 * dt;
      if (player.z <= 0) { player.z = 0; player.vz = 0; }
    }
    player.slide = Math.max(0, player.slide - dt);
    invulnerable = Math.max(0, invulnerable - dt);
    spawnTimer -= dt;
    if (spawnTimer <= 0) {
      spawnObstacle();
      spawnTimer = clamp(1.77 - elapsed / 150, 1.18, 1.77) + rnd(.0, .48);
    }
    const pHeight = player.slide > 0 ? 37 : 79;
    const pbox = { x: player.x - 20, y: FLOOR - player.z - pHeight, w: 40, h: pHeight };
    for (const obj of objects) {
      obj.x -= speed * dt;
      if (obj.hit) continue;
      if (obj.type === 'coin') {
        if (collide(pbox, { x: obj.x - 11, y: obj.y - 11, w: 22, h: 22 })) {
          obj.hit = true; runCoins++; score += 10; beep('coin'); addParticles(obj.x, obj.y, '#ffdf66', 7, 115);
        }
      } else if (obj.type === 'pothole') {
        if (obj.x + 12 < pbox.x + pbox.w && obj.x + obj.width - 12 > pbox.x && player.z < 30) { obj.hit = true; damage(); }
      } else {
        const box = obj.type === 'crate' ? { x: obj.x + 4, y: FLOOR - 50, w: obj.width - 8, h: 50 } :
          { x: obj.x, y: FLOOR - 105, w: obj.width, h: 60 };
        if (collide(pbox, box)) { obj.hit = true; damage(); }
      }
    }
    objects = objects.filter(o => o.x + o.width > -30 && !(o.type === 'coin' && o.hit));
    score = Math.floor(distance / 3.5) + runCoins * 10;
    for (const p of particles) { p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 220 * dt; p.life -= dt; }
    particles = particles.filter(p => p.life > 0);
    updateHUD();
  }

  // Canvas illustration helpers (no downloaded images/fonts).
  function rect(x, y, w, h, color) { ctx.fillStyle = color; ctx.fillRect(x, y, w, h); }
  function rounded(x, y, w, h, r, color) { ctx.fillStyle = color; ctx.beginPath(); ctx.roundRect(x, y, w, h, r); ctx.fill(); }
  function path(points, color) { ctx.beginPath(); ctx.moveTo(points[0][0], points[0][1]); for (let i = 1; i < points.length; i++) ctx.lineTo(points[i][0], points[i][1]); ctx.closePath(); ctx.fillStyle = color; ctx.fill(); }
  function ellipse(x, y, rx, ry, color) { ctx.fillStyle = color; ctx.beginPath(); ctx.ellipse(x, y, Math.max(.1, rx), Math.max(.1, ry), 0, 0, Math.PI * 2); ctx.fill(); }
  function line(x1, y1, x2, y2, width, color) { ctx.strokeStyle = color; ctx.lineWidth = width; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
  function text(str, x, y, size, color, weight = 800) { ctx.textAlign = 'center'; ctx.fillStyle = color; ctx.font = `${weight} ${size}px system-ui`; ctx.fillText(str, x, y); }
  function drawCloud(x, y, size, alpha = 1) {
    ctx.save(); ctx.globalAlpha = alpha;
    ellipse(x, y + 7 * size, 55 * size, 12 * size, '#ffffff');
    ellipse(x - 28 * size, y + 2 * size, 20 * size, 15 * size, '#ffffff');
    ellipse(x + 1 * size, y - 9 * size, 31 * size, 23 * size, '#ffffff');
    ellipse(x + 29 * size, y, 24 * size, 15 * size, '#ffffff'); ctx.restore();
  }
  function drawHillLayer(offset, baseY, heights, color, period) {
    ctx.beginPath(); ctx.moveTo(-10, H);
    for (let x = -10; x <= W + 15; x += 10) {
      const worldX = x + offset;
      const hill = Math.sin(worldX / period) * heights + Math.sin(worldX / (period * .46) + 2) * (heights * .22);
      ctx.lineTo(x, baseY - hill);
    }
    ctx.lineTo(W + 15, H); ctx.closePath(); ctx.fillStyle = color; ctx.fill();
  }
  function drawPalm(x, y, scale) {
    line(x, y, x + 10 * scale, y - 103 * scale, 10 * scale, '#684a38');
    line(x + 1 * scale, y - 13 * scale, x + 12 * scale, y - 94 * scale, 3 * scale, '#95704b');
    const topX = x + 10 * scale, topY = y - 108 * scale;
    for (let i = 0; i < 7; i++) {
      const a = Math.PI * (.85 + i * .205);
      const dx = Math.cos(a) * 55 * scale;
      const dy = Math.sin(a) * 30 * scale;
      path([[topX, topY], [topX + dx*.47,topY + dy - 10*scale], [topX + dx,topY + dy + 19*scale], [topX + dx*.6,topY + dy + 3*scale]], i%2?'#2a715a':'#378569');
    }
    ellipse(topX, topY, 7 * scale, 5 * scale, '#5f4a29');
  }
  function drawMarket(x, y, variant) {
    const w = 94, top = y - 83;
    // Simple roadside market stall with traditional-inspired colors, fictional text.
    rect(x + 9, top + 15, 4, 72, '#684633'); rect(x + 83, top + 15, 4, 72, '#684633');
    rounded(x + 2, top + 58, 92, 28, 3, '#91673e'); rect(x + 6, top + 57, 83, 5, '#e6b879');
    path([[x - 4, top + 20],[x + 16, top - 6],[x + 81, top - 6],[x + 101,top + 20]], '#8c3440');
    for (let i = 0; i < 5; i++) path([[x + i*20,top + 19],[x + (i+1)*20,top + 19],[x+(i+1)*20,top + 28],[x+i*20,top + 28]], (i + variant)%2?'#f7df8a':'#e36a54');
    for (let i = 0; i < 5; i++) ellipse(x + 16 + i * 15, top + 55, 7, 6, i%2?'#ffe180':'#6fc88d');
    rect(x + 27, top + 32, 42, 13, '#224a4c'); text(variant%2?'MARKET':'FRESH',x+48,top+42,9,'#fff2ce');
  }
  function drawBuilding(x, y, variant) {
    const widths = [75,88,62], w = widths[variant%3], h = 55+(variant*11)%33;
    rect(x,y-h,w,h, ['#cfaa80','#d9c28e','#b9a89d'][variant%3]);
    path([[x-9,y-h],[x+w/2,y-h-25],[x+w+9,y-h]],variant%2?'#964b41':'#4c6b73');
    for(let i=0;i<2;i++) rounded(x+10+i*(w/2),y-h+14,14,18,1,'#426675');
    rounded(x+w-26,y-32,17,32,1,'#835e42');
  }
  function background() {
    const sky = ctx.createLinearGradient(0,0,0,FLOOR);
    sky.addColorStop(0,'#67b6d2'); sky.addColorStop(.66,'#d7dfbb'); sky.addColorStop(1,'#f9d695');
    ctx.fillStyle = sky;ctx.fillRect(0,0,W,H);
    ellipse(754,119,64,64,'#ffdc8d'); ellipse(754,119,44,44,'#fff0b8');
    for(let i=0;i<5;i++){const xx=((i*271 - sceneOffset*.065)%(W+300)+(W+300))%(W+300)-130;drawCloud(xx,60+i%3*39,.7+i%2*.25,.7);}
    drawHillLayer(sceneOffset*.1,305,70,'#93a894',130);
    drawHillLayer(sceneOffset*.16,340,41,'#688f84',95);
    rect(0,349,W,74,'#5c928b');
    // Ocean glimpses and a sandy coastal edge between ridges and roadside.
    for(let i=0;i<17;i++){const x=((i*84-sceneOffset*.23)%(W+84)+(W+84))%(W+84);line(x,365+(i%3)*8,x+31,365+(i%3)*8,2,'#b2d4c0');}
    drawHillLayer(sceneOffset*.24,385,17,'#628668',76);
    for(let i=0;i<13;i++){
      const x=((i*118+13-sceneOffset*.37)%(W+180)+(W+180))%(W+180)-110;
      if(i%4===0) drawPalm(x+40,408,.7);
      else if(i%3===0) drawMarket(x,413,i);
      else drawBuilding(x,405,i);
    }
    rect(0,405,W,22,'#609267');rect(0,418,W,11,'#d4a26f');
    rect(0,429,W,H-429,'#57636d');rect(0,429,W,6,'#414c53');
    rect(0,452,W,2,'#7d8078');
    for(let i=-1;i<8;i++) {
      const x=((i*170-sceneOffset*.9)%(W+170)+(W+170))%(W+170)-90;
      rounded(x,488,91,5,2,'#e8c580');
    }
    for(let i=0;i<28;i++){const x=((i*53-sceneOffset)%(W+60)+(W+60))%(W+60);rect(x,441+i%4*19,6,2,'#8b9090');}
    const curb = ctx.createLinearGradient(0,526,0,540);curb.addColorStop(0,'#49545b');curb.addColorStop(1,'#39454e');rect(0,520,W,20,curb);
  }
  function drawCoin(x,y) {
    ellipse(x, y+2, 13, 14, '#9d632a');ellipse(x,y-1,12,13,'#ffd261');
    ellipse(x-1,y-2,9,10,'#ffec98');
    ctx.strokeStyle='#d99735';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x-1,y-2,7,0,Math.PI*2);ctx.stroke();
    text('K',x-1,y+3,12,'#ab692d',1000);
  }
  function drawCrate(x) {
    rounded(x+2,FLOOR-50,49,50,4,'#624436');rect(x+5,FLOOR-47,43,44,'#b7814b');
    rect(x+5,FLOOR-45,43,5,'#e2b47a');rect(x+8,FLOOR-44,6,41,'#d2a267');rect(x+39,FLOOR-44,6,41,'#d2a267');
    line(x+12,FLOOR-37,x+40,FLOOR-10,5,'#7a4e37');line(x+40,FLOOR-37,x+12,FLOOR-10,5,'#7a4e37');
    for(const xx of [10,41]) for(const yy of [-40,-10]) ellipse(x+xx,FLOOR+yy,2,2,'#e7c794');
  }
  function drawPothole(x,w) {
    ellipse(x+w/2,FLOOR+2,w/2+4,13,'#cf935b');ellipse(x+w/2,FLOOR+3,w/2,9,'#35444d');
    ellipse(x+w/2+5,FLOOR+5,w/2-13,5,'#172a35');
    line(x+12,FLOOR+1,x+24,FLOOR-2,2,'#ffd59a');line(x+w-25,FLOOR,x+w-13,FLOOR-2,2,'#ffd59a');
  }
  function drawBanner(x, w) {
    // Dangling low obstacle. The character must slide under its bottom edge.
    line(x+9,FLOOR-152,x+9,FLOOR-105,3,'#53636c');line(x+w-7,FLOOR-152,x+w-7,FLOOR-105,3,'#53636c');
    rounded(x-4,FLOOR-105,w+8,61,6,'#834b42');rounded(x,FLOOR-101,w,53,4,'#f8d17e');
    rect(x+4,FLOOR-95,w-8,6,'#d34c42');text('DUCK!',x+w/2,FLOOR-68,17,'#783e37',1000);
    for(let i=0;i<5;i++) path([[x+i*w/5,FLOOR-51],[x+(i+.5)*w/5,FLOOR-43],[x+(i+1)*w/5,FLOOR-51]], '#db704e');
  }
  function drawPlayer() {
    ctx.save();
    if (invulnerable > 0 && Math.floor(t*12)%2===0) ctx.globalAlpha=.38;
    const x = player.x, y = FLOOR - player.z, slide = player.slide > 0;
    ellipse(x+4,FLOOR+7,slide?29:19,5,'#273a4388');
    ctx.translate(x,y);
    if(slide){
      // Sliding: compact silhouette entirely below the low banner.
      rounded(-24,-19,61,21,9,'#e6e0c8');
      rounded(-32,-11,18,11,4,'#283949');
      rounded(-11,-31,35,24,7,outfits[save.outfit].color);
      rounded(15,-35,26,23,11,'#865239');
      ellipse(31,-23,2,2,'#151f23');
      path([[16,-35],[26,-46],[39,-37],[38,-31]],'#233b43');
      line(-4,-8,-28,-4,8,'#835339');
    }else{
      const run = player.z > 0 ? .15 : Math.sin(player.step*1.7);
      const kicking = player.z > 0 ? -8 : run*15;
      // Backpack, legs, arms, and cap create a recognisable player silhouette.
      rounded(-22,-63,18,34,6,'#d3a852');
      line(-9,-29,-13+kicking,FLOOR*0-FLOOR*0-8,12,'#2e3e53');
      line(9,-29,11-kicking,-8,12,'#2e3e53');
      rounded(-27+kicking,-11,27,11,4,'#293945');
      rounded(1-kicking,-11,28,11,4,'#293945');
      rounded(-18,-66,35,40,7,outfits[save.outfit].color);
      rect(-15,-31,29,7,'#3f5161');
      line(-13,-55,-22-run*5,-33+run*6,10,'#935d3d');
      line(13,-55,19+run*5,-34-run*6,10,'#935d3d');
      ellipse(-1,-76,19,21,'#9d6343');
      ellipse(-16,-75,4,7,'#9d6343');
      ellipse(8,-79,2,2,'#1b2025');
      line(5,-69,13,-68,2,'#623c2a');
      path([[-21,-88],[-12,-101],[6,-103],[19,-91],[19,-87]],'#263b42');
      rounded(-2,-94,26,6,2,'#243942');
      rounded(-12,-62,17,7,3,'#ffd783');
    }
    ctx.restore();
  }
  function render() {
    background();
    // Obstacles and rewards move across the road from right to left.
    for (const o of objects) {
      if(o.type==='coin') drawCoin(o.x,o.y);
      else if(o.type==='crate') drawCrate(o.x);
      else if(o.type==='pothole') drawPothole(o.x,o.width);
      else if(o.type==='banner') drawBanner(o.x,o.width);
    }
    // Character remains visible on the menu screen as a living game backdrop.
    drawPlayer();
    for(const p of particles) { ctx.save();ctx.globalAlpha=clamp(p.life/p.maxLife,0,1);rounded(p.x,p.y,p.size,p.size,1,p.color);ctx.restore(); }
    if(invulnerable>1.35 && state==='running') rect(0,0,W,H,'#ff585528');
    if(state==='running' && elapsed<5){ctx.save();ctx.globalAlpha=clamp((5-elapsed)/2,0,1)*.9;
      rounded(348,333,256,35,18,'#153341ba');text('↑ JUMP     ↓ SLIDE',476,355,15,'#fff0bc',900);ctx.restore();}
    if(state==='paused') rect(0,0,W,H,'#00000044');
  }
  function frame(now) {
    const dt = clamp(last ? (now-last)/1000 : 0,0,.035);last=now;
    update(dt); render();requestAnimationFrame(frame);
  }

  document.addEventListener('click', async event => {
    const btn = event.target.closest('[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;
    if (action==='play') startRun();
    else if(action==='menu') showMenu();
    else if(action==='locker') showLocker();
    else if(action==='how') showHow();
    else if(action==='pause') pause();
    else if(action==='resume') resume();
    else if(action==='quit') finishRun();
    else if(action.startsWith('outfit:')) {
      const id = action.split(':')[1]; const item = outfits[id]; if(!item) return;
      if(save.unlocked.includes(id)){save.outfit=id;beep('shop');persist();showLocker();}
      else if(save.bank >= item.price){save.bank -= item.price;save.unlocked.push(id);save.outfit=id;beep('shop');persist();showLocker();notify('OUTFIT UNLOCKED!');}
      else notify('NEED ' + (item.price-save.bank) + ' MORE COINS');
    } else if(action==='share') {
      const shareText=`I scored ${fmt(score)} points in PNG Adventure: Moresby Run! Can you beat my score?`;
      try { if(navigator.share && /^https?:$/.test(location.protocol)) await navigator.share({title:'PNG Adventure',text:shareText,url:location.href});
        else if(navigator.clipboard && window.isSecureContext){await navigator.clipboard.writeText(shareText + (location.protocol.startsWith('http')?' '+location.href:''));notify('SCORE COPIED!');}
        else notify('SCORE: ' + fmt(score) + ' POINTS');
      } catch(e){if(e.name!=='AbortError')notify('SHARE NOT AVAILABLE');}
    }
  });
  touchControls.addEventListener('pointerdown', event => {
    const btn=event.target.closest('[data-control]');if(!btn)return;
    event.preventDefault();
    if(btn.dataset.control==='jump')jump();else slide();
    btn.classList.add('pressed');setTimeout(()=>btn.classList.remove('pressed'),140);
  });
  document.addEventListener('keydown', event => {
    const code=event.code;
    if(['Space','ArrowUp','ArrowDown'].includes(code))event.preventDefault();
    if(state==='running'){
      if((code==='Space'||code==='ArrowUp'||code==='KeyW')&&!event.repeat)jump();
      else if((code==='ArrowDown'||code==='KeyS')&&!event.repeat)slide();
      else if(code==='KeyP'||code==='Escape')pause();
    }else if(state==='paused'&&(code==='KeyP'||code==='Escape'||code==='Space'))resume();
    else if((state==='menu'||state==='over')&&code==='Enter')startRun();
  });
  // Pause rather than silently losing a run when someone switches tabs or answers a call.
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&state==='running')pause();});
  window.addEventListener('blur',()=>{if(state==='running')pause();});
  showMenu(); requestAnimationFrame(frame);
})();
